<!DOCTYPE html>
<html>
	<head>
		<title>Asociación Cultural Freak's Party</title>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1">
		<meta name="theme-color" content="#2794b3">
		<meta name="mobile-web-app-capable" content="yes">
     	<link rel="icon" sizes="192x192" href="img/logo.png">
		<link href="https://fonts.googleapis.com/css?family=Ubuntu:400,700" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/styles.css">
	</head>
	<body>
		<?php
			if(isset($_GET['receive']) && $_GET['receive']=="true"){
		?>
		<div class="alert alert-success" role="alert">
		  <strong>TODO CORRECTO!!</strong> Hemos recibido tu solicitud y la atenderemos lo antes posible.
		</div>
		<?php
			}else if(isset($_GET['receive'])){
		?>
		<div class="alert alert-danger" role="alert">
		  <strong>OMG!!</strong> No sabemos como explicarlo pero... la hemos liao. Se ha producido un error en el envío del formulario y no lo hemos recibido :(
		</div>
		<?php
			}
		?>
		<nav class="menu">
			<div class="container">
				<div class="logo">
					<img src="img/logo.png" alt="Logo Freak's Party" title="Logo Freak's Party"/>
				</div>
				<div class="content-menu">
					<ul>
						<li><a href="#quienes-somos">Quiénes somos</a></li>
						<li><a href="#eventos">Eventos</a></li>
						<li><a href="#estatutos">Estatutos</a></li>
						<li><a href="#contacto">Contacto</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<div class="container">
			<div class="content">
				<section id="slider">
					<div class="slider">
						<div class="slide slide1 active" num="1"></div>
						<div class="slide slide2" num="2"></div>
						<div class="slide slide3" num="3"></div>
						<div class="slide slide4" num="4"></div>
					</div>
				</section>
				<section id="quienes-somos">
					<h2>Quiénes somos</h2>
					<p>Freak's Party es una asociación sin ánimo de lucro formada principalmente por jóvenes estudiantes de las tecnologías de la información.</p>
					<p>Nuestra asociación fué fundada inicialmente como plataforma para la organización de la Lan Party FIC OnLan. Tras el éxito y gratificación obtenidos del evento decidimos expandir nuestros horizontes con nuevas actividades.</p>
					<p>Si eres joven apasionado por la informática o simplemente compartes el interés por alguna de las actividades que realizamos siéntete libre de contactar con nosotros para asociarte o coolaborar libremente.</p>
					<p>También puedes proponernos nuevos eventos, si tu localidad o pueblo carece de Lan Party y crees que podría tener éxito, ponte en contacto con nosotros y valoraremos la viavilidad.</p>
				</section>
				<section id="eventos">
					<h2>Nuestros eventos</h2>
					<div class="event">
						<a href="https://ficonlan.es" target="_blank">
							<img src="img/logo_fol.png" alt="FicOnLan" title="FicOnLan"/>
						</a>
					</div>
				</section>
				<section id="estatutos">
					<div class="cta">
						<div>Estatutos de la asociación para consulta pública</div>
						<a href="Estatutos.pdf" target="_blank" class="fp-button">Estatutos</a>
					</div>
				</section>
				<section id="contacto">
					<h2>Contacta con nosotros</h2>
					<form id="form" action="sendform.php" method="POST">
						<input type="text" name="name" placeholder="Nombre"/>
						<input type="email" name="email" placeholder="Email"/>
						<input type="text" name="subject" placeholder="Asunto"/>
						<textarea name="message" placeholder="Escríbenos lo que quieras! :)" rows="6"></textarea>
						<button type="submit" class="fp-button-form">Enviar</button>
					</form>
				</section>
			</div>
			<footer>
				
			</footer>
		</div>
	</body>
	<script
	  src="https://code.jquery.com/jquery-3.3.1.min.js"
	  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
	  crossorigin="anonymous"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
</html>