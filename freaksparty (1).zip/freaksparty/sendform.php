<?php
	$to = "contacto@freaksparty.org";
	$subject = "Contacto desde la web";
	$message="Nombre: ".$_POST['name']."\n";
	$message.="Email: ".$_POST['email']."\n";
	$message.="Asunto: ".$_POST['subject']."\n";
	$message.="Mensaje: \n".$_POST['message']."\n";
	$headers = "From: contacto@freaksparty.org";

	if( mail($to, $subject, $message, $headers) ){
		header("Location: https://".$_SERVER["HTTP_HOST"]."?receive=true");
	}
	else{
		header("Location: https://".$_SERVER["HTTP_HOST"]."?receive=false");
	}
?>