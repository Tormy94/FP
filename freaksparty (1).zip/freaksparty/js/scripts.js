var crt=1;
const urlParams = new URLSearchParams(window.location.search);

$(function(){
	console.log( urlParams.get('receive') );

	if(urlParams.get('receive') && urlParams.get('receive')==="true"){
		$(".alert.alert-success").fadeIn();
	}
	else if(urlParams.get('receive')){
		$(".alert.alert-danger").fadeIn();
	}

	setTimeout(function(){
		changeSlide();
	}, 5000);

	if($(".alert").is(":visible")){
		setTimeout(function(){
			$(".alert").fadeOut(2000);
		}, 3000);
	}
});

function changeSlide(){
	var slides=$(".slider .slide").length;
	var origin=crt;

	if(slides==crt){
		crt=1;
		$(".slider .slide[num!="+origin+"]").css({left: "-100vw"});
	}
	else crt ++;

	$(".slider .slide[num="+origin+"]").animate({left: '100vw'}, 1000);
	$(".slider .slide[num="+crt+"]").animate({left: 0}, 1000);
		setTimeout(function(){
			changeSlide();
		}, 5000);
}